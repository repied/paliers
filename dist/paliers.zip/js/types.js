export {};
// translations.ts
